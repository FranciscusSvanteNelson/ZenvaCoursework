package com.example.mykotlinapp

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import java.util.*

class MainActivity : AppCompatActivity() {

    private var colorInput: EditText? = null
    private var colorOutput: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        colorInput = findViewById<EditText>(R.id.colorInput)
        colorOutput = findViewById<TextView>(R.id.colorOutput)
    }

    fun updateColorText(view: View) {
        val color = colorInput?.text.toString().lowercase()
        when (color) {
            "blue" -> {
                colorOutput?.text = "Your favorite is BLUE"
                colorOutput?.setTextColor(Color.BLUE)
            }
            "red" -> {
                colorOutput?.text = "Your favorite is RED"
                colorOutput?.setTextColor(Color.RED)
            }
            "green" -> {
                colorOutput?.text = "Your favorite is GREEN"
                colorOutput?.setTextColor(Color.GREEN)
            }
            "yellow" -> {
                colorOutput?.text = "Your favorite is YELLOW"
                colorOutput?.setTextColor(Color.YELLOW)
            }
            "black" -> {
                colorOutput?.text = "Your favorite is BLACK"
                colorOutput?.setTextColor(Color.BLACK)
            }
            "white" -> {
                colorOutput?.text = "Your favorite is WHITE"
                colorOutput?.setTextColor(Color.LTGRAY)
            }
            else -> {
                colorOutput?.text = "Excellent Choice!"
                colorOutput?.setTextColor(Color.MAGENTA)
            }
        }
    }

}